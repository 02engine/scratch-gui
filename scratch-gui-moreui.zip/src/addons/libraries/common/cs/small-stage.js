export default function addSmallStageClass() {
  // TW: no-op; sa-small-stage class is handled by scratch-gui
}
