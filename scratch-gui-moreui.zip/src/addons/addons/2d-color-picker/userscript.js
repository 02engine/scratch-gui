import paintEditorHandler from "./paint-editor.js";

export default async (api) => {
  paintEditorHandler(api);
};
