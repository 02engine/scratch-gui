import codeEditorHandler from "./code-editor.js";

export default async (api) => {
  codeEditorHandler(api);
};
